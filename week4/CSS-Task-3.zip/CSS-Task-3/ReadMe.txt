In this Task you are to build a Responsive website using the link below and the support materials attached in the file.

https://templatemo.com/live/templatemo_590_topic_listing

All that you need is in the files provided, All the Best Genes!